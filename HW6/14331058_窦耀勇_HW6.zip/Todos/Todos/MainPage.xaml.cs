﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.DataTransfer;
using Windows.Data.Xml.Dom;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Notifications;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using SQLitePCL;

//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace Todos
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            var viewTitleBar = Windows.UI.ViewManagement.ApplicationView.GetForCurrentView().TitleBar;
            viewTitleBar.BackgroundColor = Windows.UI.Colors.CornflowerBlue;
            viewTitleBar.ButtonBackgroundColor = Windows.UI.Colors.CornflowerBlue;
            this.ViewModel = new ViewModels.TodoItemViewModel();

            LoadDatabase();
        }
        //for database
        private void LoadDatabase()
        {
            // Get a reference to the SQLite database
            string sql = @"CREATE TABLE IF NOT EXISTS TodoItem (Id    INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, 
                                                                                                       Title    VARCHAR( 140 ),
                                                                                                       Context    VARCHAR( 140 ),
                                                                                                       Date    TEXT);";
            using (var statement = App.TodoDb.Prepare(sql))
            {
                statement.Step();
            }

            // read the data from database into todoItem
            var dbconn = App.TodoDb;
            using (var statement = dbconn.Prepare("SELECT * FROM TodoItem"))
            {
                while (SQLiteResult.ROW == statement.Step())
                {
                    ViewModel.AddTodoItem((string)statement[1], (string)statement[2], DateTimeOffset.Parse((string)statement[3]));
                }
            }
        }

        public void insert_to_db(object sender, RoutedEventArgs e)
        {
            var db = App.TodoDb;
            try
            {
                using (var new_todo = db.Prepare("INSERT INTO TodoItem (Title, Context, Date) VALUES (?, ?, ?)"))
                {
                    new_todo.Bind(1, title.Text);
                    new_todo.Bind(2, details.Text);
                    new_todo.Bind(3, calendar.Date.ToString());
                    new_todo.Step();
                }
            }
            catch (Exception ex)
            {
                // TODO: Handle error}
            }
        }

        private string query_from_db(object sender, RoutedEventArgs e)
        {
            string one_todo = "";

            var dbconn = App.TodoDb;
            using (var statement = dbconn.Prepare("SELECT Id, Title, Context, Date FROM TodoItem WHERE Title LIKE ? OR  Context LIKE ? OR  Date LIKE ?"))
            {
                statement.Bind(1, "%" + Query.Text+ "%");
                statement.Bind(2, "%" + Query.Text + "%");
                statement.Bind(3, "%" + Query.Text + "%");
                while (SQLiteResult.ROW == statement.Step())
                {
                    one_todo = one_todo + "id : " + statement[0].ToString()+ " ;\tTitle : " + (string)statement[1] + " ;\tContext : " + (string)statement[2] + " ;\tDate : " + statement[3].ToString() + "\n";
                }
            }
            return one_todo;
        }
        ViewModels.TodoItemViewModel ViewModel { get; set; }
        
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (e.Parameter.GetType() == typeof(ViewModels.TodoItemViewModel))
            {
                this.ViewModel = (ViewModels.TodoItemViewModel)(e.Parameter);
            }
        }

        private void TodoItem_ItemClicked(object sender, ItemClickEventArgs e)
        {
            ViewModel.SelectedItem = (Models.TodoItem)(e.ClickedItem);
            Frame.Navigate(typeof(NewPage), ViewModel);
        }
        private void CreateButton_Clicked(object sender, RoutedEventArgs e)
        {
            // check the textbox and datapicker
            // if ok
            bool isToCreate = true;

            if (title.Text == "")
            {
                var inspire = new MessageDialog("标题不可以为空").ShowAsync();
                isToCreate = false;
            }
            else if (details.Text == "")
            {
                var inspire = new MessageDialog("详情不可以为空").ShowAsync();
                isToCreate = false;
            }
            else
            {
                //检测日期是否合理
                //获取设置的日期
                DateTimeOffset setTime = calendar.Date;
                //获取当日日期
                DateTimeOffset thisTime = new DateTimeOffset(DateTime.Today);
                //比较时间设置是否合理
                if (thisTime.CompareTo(setTime) > 0)
                {
                    var inspire = new MessageDialog("设置的时间不可以早于今天").ShowAsync();
                    isToCreate = false;
                }
            }

            if (isToCreate)
            {
                ViewModel.AddTodoItem(title.Text, details.Text, calendar.Date);
                Frame.Navigate(typeof(MainPage), ViewModel);

                insert_to_db(sender, e);
            }
        }

        private void AddAppBarButton_Click(object sender, RoutedEventArgs e)
        {
            if (InlineToDoItemViewGrid.Visibility == Visibility.Collapsed)
            {
                Frame.Navigate(typeof(NewPage), ViewModel);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            title.Text = "";
            details.Text = "";
            calendar.Date = new DateTimeOffset(DateTime.Today);
        }

        private void isCheck_Checked(object sender, RoutedEventArgs e)
        {

        }
        //
        private void OnClick(object sender, RoutedEventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();
            xdoc.LoadXml(File.ReadAllText("tile.xml"));

            Models.TodoItem newestItem = ViewModel.AllItems.Last<Models.TodoItem>();
            var elements = xdoc.GetElementsByTagName("text");

            //small
            elements[0].InnerText = newestItem.title;
            elements[1].InnerText = newestItem.description;
            elements[2].InnerText = newestItem.date.ToString();

            //midium

            elements[3].InnerText = newestItem.title;
            elements[4].InnerText = newestItem.description;
            elements[5].InnerText = newestItem.date.ToString();

            //wide
            elements[6].InnerText = newestItem.title;
            elements[7].InnerText = newestItem.description;
            elements[8].InnerText = newestItem.date.ToString();

            var updator = TileUpdateManager.CreateTileUpdaterForApplication();
            var notification = new TileNotification(xdoc);

            updator.Update(notification);
        }

        private MenuFlyoutItem selectedMenu;
        private Models.TodoItem selectedItem;

        private void share_click(object sender, RoutedEventArgs e)
        {
            selectedMenu = (MenuFlyoutItem)sender;
            selectedItem = (Models.TodoItem)selectedMenu.DataContext;

            DataTransferManager.GetForCurrentView().DataRequested += OnShareDataRequested;
            DataTransferManager.ShowShareUI();
        }

        private async void OnShareDataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {
            var dp = args.Request.Data;
            var deferral = args.Request.GetDeferral();
            var photoFile = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appx:///Assets/background.jpg"));
            dp.SetStorageItems(new List<StorageFile> { photoFile });

            dp.Properties.Title = selectedItem.title;
            dp.Properties.Description = selectedItem.description;

            dp.SetText("事件标题:\n"+ selectedItem.title + "\n详情内容:\n"+selectedItem.description);
            deferral.Complete();


        }

        private void BtnGetAll_Click(object sender, RoutedEventArgs e)
        {
            string one_item =  query_from_db(sender, e);

            if (one_item != null)
            {
                var inspire = new MessageDialog(one_item).ShowAsync();
            } else
            {
                var inspire = new MessageDialog("Can't find any info!").ShowAsync();
            }
        }
    }
}
