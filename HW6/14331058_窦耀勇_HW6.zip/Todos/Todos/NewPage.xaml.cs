﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;


namespace Todos
{
    public sealed partial class NewPage : Page
    {
        public NewPage()
        {
            this.InitializeComponent();
            var viewTitleBar = Windows.UI.ViewManagement.ApplicationView.GetForCurrentView().TitleBar;
            viewTitleBar.BackgroundColor = Windows.UI.Colors.CornflowerBlue;
            viewTitleBar.ButtonBackgroundColor = Windows.UI.Colors.CornflowerBlue;

        }

        private ViewModels.TodoItemViewModel ViewModel;

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            ViewModel = ((ViewModels.TodoItemViewModel)e.Parameter);
            if (ViewModel.SelectedItem == null)
            {
                createButton.Content = "Create";
                createButton.Click -= UpdateButton_Clicked;
                createButton.Click -= CreateButton_Clicked;
                createButton.Click += CreateButton_Clicked;
                //var i = new MessageDialog("Welcome!").ShowAsync();
            }
            else
            {
                createButton.Content = "Update";
                createButton.Click -= CreateButton_Clicked;
                createButton.Click += UpdateButton_Clicked;
                title.Text = ViewModel.SelectedItem.title;
                details.Text = ViewModel.SelectedItem.description;
                calendar.Date = ViewModel.SelectedItem.date;
                // ...
            }
        }


        private void CreateButton_Clicked(object sender, RoutedEventArgs e)
        {
            // check the textbox and datapicker
            // if ok
            bool isToCreate = true;

            if (title.Text == "")
            {
                var inspire = new MessageDialog("标题不可以为空").ShowAsync();
                isToCreate = false;
            }
            else if (details.Text == "")
            {
                var inspire = new MessageDialog("详情不可以为空").ShowAsync();
                isToCreate = false;
            }
            else
            {
                //检测日期是否合理
                //获取设置的日期
                DateTimeOffset setTime = calendar.Date;
                //获取当日日期
                DateTimeOffset thisTime = new DateTimeOffset(DateTime.Today);
                //比较时间设置是否合理
                if (thisTime.CompareTo(setTime) > 0)
                {
                    var inspire = new MessageDialog("设置的时间不可以早于今天").ShowAsync();
                    isToCreate = false;
                }
            }

            if (isToCreate)
            {
                ViewModel.AddTodoItem(title.Text, details.Text, calendar.Date);
                Frame.Navigate(typeof(MainPage), ViewModel);

                insert_to_db(sender, e);
            }
            ViewModel.SelectedItem = null;
        }

        private  void DeleteButton_Clicked(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedItem != null)
            {
                //delete from database
                delete_from_db(sender, e);

                ViewModel.RemoveTodoItem(ViewModel.SelectedItem);
                Frame.Navigate(typeof(MainPage), ViewModel);
            }
        }
        private void delete_from_db(object sender, RoutedEventArgs e)
        {
            using (var statement = App.TodoDb.Prepare("DELETE FROM TodoItem WHERE Title = ? AND Context = ? AND Date = ?"))
            {
                statement.Bind(1, ViewModel.SelectedItem.title);
                statement.Bind(2, ViewModel.SelectedItem.description);
                statement.Bind(3, ViewModel.SelectedItem.date.ToString());
                statement.Step();
            }
        }

        private void UpdateButton_Clicked(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedItem != null)
            {
                bool isToUpdate = true;

                if (title.Text == "")
                {
                    var inspire = new MessageDialog("标题不可以为空").ShowAsync();
                    isToUpdate = false;
                }
                else if (details.Text == "")
                {
                    var inspire = new MessageDialog("详情不可以为空").ShowAsync();
                    isToUpdate = false;
                }
                else
                {
                    //检测日期是否合理
                    //获取设置的日期
                    DateTimeOffset setTime = calendar.Date;
                    //获取当日日期
                    DateTimeOffset thisTime = new DateTimeOffset(DateTime.Today);
                    //比较时间设置是否合理
                    if (thisTime.CompareTo(setTime) > 0)
                    {
                        var inspire = new MessageDialog("设置的时间不可以早于今天").ShowAsync();
                        isToUpdate = false;
                    }
                }

                if (isToUpdate)
                {
                    DeleteButton_Clicked(sender, e);
                    ViewModel.AddTodoItem(title.Text, details.Text, calendar.Date);
                    insert_to_db(sender, e);
                    Frame.Navigate(typeof(MainPage), ViewModel);
                }
                // check then update
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            title.Text = "";
            details.Text = "";
            calendar.Date = new DateTimeOffset(DateTime.Today);
        }
        //
        public void insert_to_db(object sender, RoutedEventArgs e)
        {
            var db = App.TodoDb;
            try
            {
                using (var new_todo = db.Prepare("INSERT INTO TodoItem (Title, Context, Date) VALUES (?, ?, ?)"))
                {
                    new_todo.Bind(1, title.Text);
                    new_todo.Bind(2, details.Text);
                    new_todo.Bind(3, calendar.Date.ToString());
                    new_todo.Step();
                }
            }
            catch (Exception ex)
            {
                // TODO: Handle error}
            }
        }
    }
}
